#!/bin/bash
mkdir /SHARED
mkdir /root/{DEBUG,FIND,PASS,STATS,HASHES,SSH,FILES,ZIP,TERM,BIN,SBIN,PING,IP,HOME,EXP,USER,SED,CUT,.ZIP2}
 
touch /root/FIND/{1,2,3,4,5}.txt
touch /root/FIND/{6,7,8,9,0}~.txt

echo "12345" | md5sum | awk '{print $1}' > /root/ZIP/file2
echo "54321" | md5sum | awk '{print $1}' > /root/ZIP/file1
echo "54321" | md5sum | awk '{print $1}' > /root/ZIP/file3

find /{bin,sbin} -maxdepth 1 -type f -exec cp {} /root/BIN 2>/dev/null \;
find /usr/{bin,sbin} -maxdepth 1 -type f -exec cp {} /root/BIN 2>/dev/null \;
	# copies 4100+ files

#stomp.sh: randomly stomps "3" files
touch /root/PASS/stomp.sh
chmod +x /root/PASS/stomp.sh
echo '#!/bin/bash' > /root/PASS/stomp.sh
echo 'N=3' >> /root/PASS/stomp.sh
echo 'ls /root/{BIN,SBIN} | sort -R | tail -$N | \ ' >> /root/PASS/stomp.sh
echo 'while read file;' >> /root/PASS/stomp.sh
echo '	do touch /root/{BIN,SBIN}/$file;' >> /root/PASS/stomp.sh
echo '	chmod +x /root/{BIN,SBIN}/$file;' >> /root/PASS/stomp.sh
echo 'done' >> /root/PASS/stomp.sh

#kill.sh: removes script: stomp.sh, so that it only runs once, and appears only once in the logs
touch /root/PASS/kill.sh
chmod +x /root/PASS/kill.sh
echo '#!/bin/bash' > /root/PASS/kill.sh
echo '	mv /root/PASS/stomp.sh /dev/null' >> /root/PASS/kill.sh

#creates debug.sh in /root/DEBUG
touch /root/DEBUG/debug.sh
echo '#!/bin/bash' > /root/DEBUG/debug.sh
echo 'for $user in $(getent passwd | cut -d: -f1}; do' >> /root/DEBUG/debug.sh
echo '	if [[ $(crontab -u $user -l 2>/dev/null) ]] then' >> /root/DEBUG/debug.sh
echo '		$user; crontab -u $user -1 2>/dev/null;' >> /root/DEBUG/debug.sh
echo '	fi' >> /root/DEBUG/debug.sh
echo 'done' >> /root/DEBUG/debug.sh

service cron start
echo '*/5 * * * * root /bin/bash /root/PASS/stomp.sh' >> /var/spool/cron/crontabs/root
	# activates random timestomp for 3 of the /root/BIN/<files>

echo '*/6 * * * * root /bin/bash /root/PASS/kill.sh' >> /var/spool/cron/crontabs/root
	# deletes timestomp script: stomp.sh, so it only runs ONCE

for x in {LARRY,CURLY,MOE}; do
	useradd -M $x;
	echo "$x:password" | chpasswd;
done

# generates IP addresses for activity: IPs in bash_history
touch /root/list
for a in {1..3}; do
	for y in {1..3}; do
		for x in {1..100}; do
			dd if=/dev/urandom bs=4 count=1 2>/dev/null \
			| od -An -tu1 | sed -e 's/^ *//' -e 's/  */./g' >> /root/list;
		done;
	done
	N=100
	for z in {1..10}; do
		cat /root/list | sort -R | tail -$N >> /root/list;
	done;
done
touch /root/USER/.bash_history
cat /root/list >> /root/USER/.bash_history

#inject .cn IP address for students to find
for b in {1..1000}; do 
	echo "58.30.214.99" >> /root/USER/.bash_history;
done

#inject bad finds
ips=({411.411.411.411,240.10.240.10,999.999.999.999.999,1005.00.00.00,0.1.2.3})
for y in $(seq 1 3000); do
        for x in ${ips[@]}; do
                echo $x >> /root/USER/.bash_history;
        done
done


sleep 1
rm -f /root/list

#preps Activity 29 De-Compression2 Exercise
touch /root/.ZIP2/flag.txt
echo "$(echo "The Force Is Strong With You" | figlet | /usr/share/misc/class/banner.sh 118)" > /root/.ZIP2/flag.txt

touch /root/.ZIP2/compress.sh
echo '#/bin/bash' > /root/.ZIP2/compress.sh
echo 'file1="flag.txt"' >> /root/.ZIP2/compress.sh
echo 'for i in {1..20}; do' >> /root/.ZIP2/compress.sh
echo '    num=$(($RANDOM%3))' >> /root/.ZIP2/compress.sh
echo '    file2=$(head -c 1024 /dev/urandom | md5sum | cut -c1-32)' >> /root/.ZIP2/compress.sh
echo '    if [ "$num" -eq 0 ]; then' >> /root/.ZIP2/compress.sh
echo '        tar -cf "$file2" "$file1"' >> /root/.ZIP2/compress.sh
echo '        rm "$file1"' >> /root/.ZIP2/compress.sh
echo '        file1="$file2"' >> /root/.ZIP2/compress.sh
echo '    elif [ "$num" -eq 1 ]; then' >> /root/.ZIP2/compress.sh
echo '        gzip "$file1"' >> /root/.ZIP2/compress.sh
echo '        file1=$(file $(ls) | grep .gz | cut -d ':' -f 1)' >> /root/.ZIP2/compress.sh
echo '        mv "$file1" "$file2"' >> /root/.ZIP2/compress.sh
echo '        file1="$file2"' >> /root/.ZIP2/compress.sh
echo '    elif [ "$num" -eq 2 ]; then' >> /root/.ZIP2/compress.sh
echo '        bzip2 "$file1"' >> /root/.ZIP2/compress.sh
echo '        file1=$(file $(ls) | grep .bz2 | cut -d ':' -f 1)' >> /root/.ZIP2/compress.sh
echo '        mv "$file1" "$file2"' >> /root/.ZIP2/compress.sh
echo '        file1="$file2"' >> /root/.ZIP2/compress.sh
echo '    fi' >> /root/.ZIP2/compress.sh
echo 'done' >> /root/.ZIP2/compress.sh
chmod +x /root/.ZIP2/compress.sh

#30 FIFOS Challenge
#mkdir /usr/games/1337
#touch /usr/games/1337.sh
#echo '#!/bin/bash' > /usr/games/1337.sh
#	echo 'for a in {A..Z}; do' >> /usr/games/1337.sh
#		echo 'echo $a >> /usr/games/.1;' >> /usr/games/1337.sh
#	echo 'done' >> /usr/games/1337.sh
#chmod +x /usr/games/1337.sh
#/usr/games/1337.sh

#sleep 1

dirs1=({/bin,/sbin,/usr/sbin,/usr/bin,/root,/home,/etc,/media,/lib,/srv,/mnt,/usr,/usr/share/vte,/usr/share/yelp})
dirs2=({/usr/share/zenity,/usr/share/systemd,/usr/share/screen,/usr/share/python,/usr/share/themes})
dirs3=({/usr/share/poppler,/etc/sudoers.d,/etc/vim,/etc/selinux,/etc/sysctl.d,/etc/terminfo,/etc/network,/etc/modprobe.d})
#makes 14 fifos
for i in ${dirs1[@]}; do mkfifo $i/.h1-th3r3; done

#makes 5 fifos
for j in ${dirs2[@]}; do mkfifo $j/.g0tch4; done

#makes 8 fifos
for k in ${dirs3[@]}; do mkfifo $k/.u-d0n-cm3; done

#done
#find /* ! -name "*xconsole" ! -name "*initctl" -type p -exec echo {} 2>/dev/null \;
#find / -type p -exec echo {} 2>/dev/null \;

mkdir /usr/games/files

for s in $(seq 1 27); do touch /usr/games/files/$s; done
#rm -f $(find ./* -type f -exec echo {} \; | grep [a-z])

echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaqPASSWORD:APRIL_FOOLSl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/1
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/2
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/3
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/4
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/5
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/6
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/7
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/8
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/9
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0password:HAHAHAHAHAHAHAHAH9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/10

#this one has the password in it . . near the end

echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=>tH1s-iz-Ur_paSSwOrd::qwerty::<)f5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/11
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/12
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/13
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/14
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/_passwordNOT_LOL_mIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/15
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/16
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/17
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/18
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhweeeeeeH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/19
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/20
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/21
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/22
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/23
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/24
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/25
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrhello?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/26
echo '$A9mep(,JhmAjnY5klRr;:4Pf:wvRD5Pc/!l+O#im5IF0oW!v+e.NEub;c.T4>Xy8==*EML%L,Mz5Jz>7A8YN#u)FiHi<B%$,m0)7hv7YSppZ#lXP/T2htzgZk=rGADc:0Aae-K(vL=nZ+AF \
VTiCk>S@2Ndod8k&vsyoJV(;8klpvCmVq4$,(7c9p)OKRTV4X9+<3-mde>2sR1wCNaV7fl1Y&=z@:Rc;xE*!!fnHJ2E(:&*n;3N-XSMPj>jq=-z0#CSm)CYB2f>tz2-ef98A!Tgn8:ESqIAHhO6#S@/ \
Hkw9PX%!gGTo%N28)gg6wX9#Zm@%TLN4UBA1gd<UM8GsXzj:UVPm+%UXI!@rzD8hZEW?VaKSIRz(zjON3f#/IuyL8o-r&yI(FZAC>L,#KBVvfv!<9N:wlAZ$9$RSl-)?7po:<%CvL6<LSc**ARX00Ohi \
f=Ef(hJ#/z2DU:2LjP,6%ya:k&U*luZ<Xv6k:oEtnL*Fm.+UT+0MRdmF(3#cv*w3w1/Dvyv5WmsDBp+e-dU9TIX&nhFhIObq>KH,Dj>4@;Cf>tSc5mk@I762I)W;aWVTR9KOuaM;00=Nz(.;36ZyNAPQs5 \
;MjW*qu?do5V#=*a*&E6e0gtjGyS6Lc.N446t?8!Ut*#vp(y9SLLi4nizi?O;t4!1)ir1vZb;vnl6BjTzmveYz/gJ@L7$%@CkE!Sk09Soeh*&itG=Pf0!4l2iaAHmoZGAp6RV:,vrvQ8g2/f@)vOrSkwx5j \
l.q4tKWRFzuzN?FfRv-..C,Tl>$..q!F?R6;Bu3WyO5WHD$.YHmg9.bg8-&z#0XknQe.FwG2ZXWtFKvn$m<-Hi>aKg/NbQ<o,K1S,6gH7na-6Bn.zBP,7PA0D%*ZD*Y=Q@d:Xws*(ytGm%m?Do0vMZ)JUK7+ \
PSn?cB6N.*%bK5?qn!0/SgRlyLoUb*r(asnrrUFex?3ffc+f/m>y/r2(bPrzp3@e/Lu,Al?L#T>C@Uc!sH*x!oX<EazA9I$XyE6/mew.Aiq8ZJZxo1+(lUj,IAuCWP<bE,(i2)$)?!:?5SK4iGuBYC;E0=p8g \
.>/>oz-2Iu.p(J>WQTUU2Q+--7v?k?(i7K#?L;W$F$O#,,sq>a(Lkk5-R(i!8+2=CrcLaq2ia>RYUny=@/E6TaDLWgl1nT61RD4PMGu2G7EpaLvGl<gFvVH/xjc34H0g6bt6qi/YnVIq@KgBOdoc5M%DE4J1sL \
9QUC+VOA?q>55lRpx+9,SAQJfPSZ7+RLvOg6Gipr7jpoiz@KY.7GT&;iidh--wF1R;,D;FaVRQf!pgBsqagpqfm7=cy;7o$2?b<>DVcqLUzogWg:yNRax9Q.nIAl<,/N9Ey04BiexuVCxzoBolW0Vdt<X#&6NWu \
h*W)eNS%b1Q2KXtevB>/96Jm>f)R#AaDwtxi6V*i:8mgG;gXv0KaIY(sVOvipKh#QBp=Sb5:+DI>7ewB.U.LP5gd@!Q?O(9(o6rAi&l:QV@,RW:gMc$<P98!(0yfKDQL;=V5js9ipBj->cdETNIx4$u;$edXhuuXQ \
.jU7a*$3<4nl/(#F,KeXBj0=D4Jq6P;ZEV>7PXuOB+xt&)p)9wOk.bHENE;X:2:/;-rRe.BNjdlNwZiPE5i3B5g/<ES&e9=Hl/D&&qkQ:NyC:-8+J?b+VGlr;bw2:0A&0x1CO2;2q*?k*cx(**rrXvDl2svu)j*laE \
?11N>4=K?2o>4>.K88>b-lOfPnObEPB%J!#fZGYBN3bK!<kq$11,2$7aww8Qy$?&/g39b62sJ,yCLYzSc3?gd31j=iYJl7&a<e@OXd%BvIUc;h)FVHng1z54Wf5&+SohCiVEI;;Zu#qP?yp?fouvGp;F1uci)l5q(ia \
v*jvK3*U=jCp$/C7jf$kK(@,FhbE-Pss:' >  /usr/games/files/27

#grep -ra [a-zA-z0-9] /usr/games/files/ | grep -v final | cut -d/ -f2- | sort -nk1 | column -t
#cat's contents <giberish above> to each of the fifos, as a backgrounded process

cat > /usr/share/misc/class/.1.sh <<"__EOF__"
#!/bin/bash
cat /usr/games/files/1 > /bin/.h1-th3r3 &
cat /usr/games/files/2 > /etc/sysctl.d/.u-d0n-cm3 &
cat /usr/games/files/3 > /etc/vim/.u-d0n-cm3 &
cat /usr/games/files/4 > /etc/selinux/.u-d0n-cm3 &
cat /usr/games/files/5 > /etc/sudoers.d/.u-d0n-cm3 &
cat /usr/games/files/6 > /etc/modprobe.d/.u-d0n-cm3 &
cat /usr/games/files/7 > /etc/terminfo/.u-d0n-cm3 &
cat /usr/games/files/8 > /etc/.h1-th3r3 &
cat /usr/games/files/9 > /etc/network/.u-d0n-cm3 &
cat /usr/games/files/10 > /home/.h1-th3r3 &
cat /usr/games/files/11 > /lib/.h1-th3r3 &
cat /usr/games/files/12 > /media/.h1-th3r3 &
cat /usr/games/files/13 > /mnt/.h1-th3r3 &
cat /usr/games/files/14 > /root/.h1-th3r3 &
cat /usr/games/files/15 > /sbin/.h1-th3r3 &
cat /usr/games/files/16 > /srv/.h1-th3r3 &
cat /usr/games/files/17 > /usr/bin/.h1-th3r3 &
cat /usr/games/files/18 > /usr/share/zenity/.g0tch4 &
cat /usr/games/files/19 > /usr/share/yelp/.h1-th3r3 &
cat /usr/games/files/20 > /usr/share/poppler/.u-d0n-cm3 &
cat /usr/games/files/21 > /usr/share/systemd/.g0tch4 &
cat /usr/games/files/22 > /usr/share/themes/.g0tch4 &
cat /usr/games/files/23 > /usr/share/screen/.g0tch4 &
cat /usr/games/files/24 > /usr/share/python/.g0tch4 &
cat /usr/games/files/25 > /usr/share/vte/.hi-th3r3 &
cat /usr/games/files/26 > /usr/sbin/.h1-th3r3 &
cat /usr/games/files/27 > /usr/.h1-th3r3 &
__EOF__
chmod +x /usr/share/misc/class/.1.sh
while : ; do ./.1.sh 2>/dev/null; done &

#students must find all the fifos:
#find / ! -name "*xconsole" ! -name "*fifo" ! -name "*21.ref" -type p -exec echo {} 2>/dev/null \; > fifos.txt
#students must generate a list of usable ports:
#listener -- works
#for i in $(seq 20000 20030); do echo $i >> port_list; done
#for y in $(cat port_list);do nc -nlp $y &; done
#server:
#for x in $(cat fifos.txt); do mypid=$!; nc -w 1 127.0.0.1 $(cat port_list) < $x; done
#for x in $(cat list_ports.txt); do nc -nvz -w 1 127.0.0.1 $x; done 2>&1 | grep open

#sets

#sets up Activity 30 Egg Hunt; phase 2: mona image - steghide extract
chown LARRY:root /usr/share/misc/class/mona.jpg
	#hint should they get stuck; image owned by user LARRY: find / -user LARRY -exec echo {} \;
mv /usr/share/misc/class/mona.jpg /etc/vim/.mona
touch /etc/vim/msg
echo "$(echo "Confer upon you the rank of Jedi Knight, this council does    - Y0D4" | figlet | /usr/share/misc/class/banner.sh 226)" > /etc/vim/msg
steghide embed -cf /etc/vim/.mona -ef /etc/vim/msg -p "qwerty" -q
#student solution to de-obfuscate the image:
	#steghide extract -sf /etc/vim/.mona -p "qwerty" -q >> /etc/vim/msg

#cat /etc/vim/msg
	#confer upon you the rank of Jedi, this council does     - Y0D4
	
#works to this point
