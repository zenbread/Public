if [[ -x /etc/passwd ]]; then echo file exists and is executable; else echo either file not present or not executable; fi
