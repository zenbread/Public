if [[ -s /etc/hosts.deny ]]; then echo file exists and contains content; else echo either file not present or missing content; fi
