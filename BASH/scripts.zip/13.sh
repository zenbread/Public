#!/bin/bash
if [ "$?" = "0" ] ;  then
	echo " CMD executed successfully "
else
	echo " ERROR "
fi

