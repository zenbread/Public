if [[ -d /var/log ]]; then echo /var/log PRESENT; else echo NO /var/log; fi
