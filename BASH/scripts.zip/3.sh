if [[ -f /etc/passwd ]]; then echo /etc/passwd is a Regular File; else echo NOT regular file; fi
