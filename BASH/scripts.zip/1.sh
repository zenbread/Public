if [[ -e /etc/shadow ]]; then echo /etc/shadow; else echo Nope; fi
